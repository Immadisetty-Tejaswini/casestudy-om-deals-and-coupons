import web from '../src/images/lin.svg'

const Sdata = [
    {
        imgsrc: web,
        title: "Web Development"
    },
    {
        imgsrc: web,
        title: "App Development"
    },
    {
        imgsrc: web,
        title: "Go"
    },
    {
        imgsrc: web,
        title: "Java"
    },
    {
        imgsrc: web,
        title: "Python"
    },
    {
        imgsrc: web,
        title: "Swift"
    }
]

export default Sdata;