export class User {
    userid!:string;
    useremail!:string;
    password!:number;
    constructor(){}
  }